# WPF-Dashboard-UI-Material-Design-Concept
This is just a design concept of Material Design Dashboard - Code - which is already showcased in my YouTube Channel - Caster WPF: 
Find it in https://www.youtube.com/watch?v=h962rCLfGuA
This is only a concept UI and the backend code is not there. Just an idea of Mobile Application Usage Dashboard.


![Screenshot](https://raw.githubusercontent.com/vasanthmes/WPF-Dashboard-UI-Material-Design-Concept/master/screenshots/Material-Design-WPF-Dashboard-UI-Speed-Design-Thumbnail.png)

## Getting Started

Don't know how it looks? Check out https://www.youtube.com/watch?v=h962rCLfGuA to see the end result and speed design.

## Built With

* [Material Design in XAML Toolkit](https://github.com/MaterialDesignInXAML/MaterialDesignInXamlToolkit) - Comprehensive and easy to use Material Design theme and control library for the Windows desktop.

## Authors

* **Vasanthan** - *Initial work* - [vasanthmes](https://github.com/vasanthmes)
* **CasterWPF** - *Show Cased at* - (https://www.youtube.com/channel/UCrkTODm4ryNZCrfyK6FhagA?disable_polymer=0)
#   W P F d a s h b o a r d  
 